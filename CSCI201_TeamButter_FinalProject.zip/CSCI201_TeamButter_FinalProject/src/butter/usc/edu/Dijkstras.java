package butter.usc.edu;

/* The authors of this work have released all rights to it and placed it
2 in the public domain under the Creative Commons CC0 1.0 waiver
3 (http://creativecommons.org/publicdomain/zero/1.0/).
4 
5 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
6 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
7 MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
8 IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
9 CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
10 TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
11 SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
12 
13 Retrieved from: http://en.literateprograms.org/Dijkstra's_algorithm_(Java)?oldid=15444
14 */

import java.util.PriorityQueue;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Vector;

class Vertex implements Comparable<Vertex>{
    
	Ramp ramp;
	
	public final String name;
    public int freeway;
    public String freewayName;
    public Vector<Edge> adjacencies = new Vector<Edge>();
    public double minDistance = Double.POSITIVE_INFINITY;
    public Vertex previous;
    
    public Vertex(Ramp r) {
    	ramp = r;
    	name = r.name;
    	freeway = r.freeway;
    	if (freeway == 10){
    		this.freewayName = "I-10";
    	} else if (freeway == 101){
    		this.freewayName = "US 101";
    	} else if (freeway == 105){
    		this.freewayName = "I-105";
    	} else if (freeway == 405){
    		this.freewayName = "I-405";
    	}
    }
    
    public Vertex(String argName, int freeway) { 
    	name = argName; 
    	this.freeway = freeway;
    	if (freeway == 10){
    		this.freewayName = "I-10";
    	} else if (freeway == 101){
    		this.freewayName = "US 101";
    	} else if (freeway == 105){
    		this.freewayName = "I-105";
    	} else if (freeway == 405){
    		this.freewayName = "I-405";
    	}
    }
    public String toString() { return "(" + freeway + ")" + name; }
    public int compareTo(Vertex other){
        return Double.compare(minDistance, other.minDistance);
    }
    
    public String getName(){
    	return name;
    }

}

class Edge{
    public final Vertex target;
    public final double weight;
    public Edge(Vertex argTarget, double argWeight)
    { target = argTarget; weight = argWeight; }
}

public class Dijkstras{
    public static void computePaths(Vertex source){
        source.minDistance = 0.;
        PriorityQueue<Vertex> vertexQueue = new PriorityQueue<Vertex>();
	vertexQueue.add(source);

	while (!vertexQueue.isEmpty()) {
	    Vertex u = vertexQueue.poll();

            // Visit each edge exiting u
            for (Edge e : u.adjacencies)
            {
                Vertex v = e.target;
                double weight = e.weight;
                double distanceThroughU = u.minDistance + weight;
				
                if (distanceThroughU < v.minDistance) {
				    vertexQueue.remove(v);
		
				    v.minDistance = distanceThroughU ;
				    v.previous = u;
				    vertexQueue.add(v);
				}
            }
        }
    }

    public static List<Vertex> getShortestPathTo(Vertex target){
        List<Vertex> path = new ArrayList<Vertex>();
        for (Vertex vertex = target; vertex != null; vertex = vertex.previous)
            path.add(vertex);

        Collections.reverse(path);
        return path;
    }

/* 
    public static void main(String[] args){
      Vertex v0 = new Vertex("A");
		Vertex v1 = new Vertex("B");
		Vertex v2 = new Vertex("C");
		Vertex v3 = new Vertex("D");
		Vertex v4 = new Vertex("E");
		Vertex v5 = new Vertex("F");
		Vertex v6 = new Vertex("G York");
		Vertex[] vertices = { v0, v1, v2, v3, v4, v5, v6 };
		v0.adjacencies = new Edge[]{ new Edge(v1,  79.83),
		                             new Edge(v5,  81.15) };
		v1.adjacencies = new Edge[]{ new Edge(v0,  79.75),
		                             new Edge(v2,  39.42),
		                             new Edge(v3, 103.00) };
		v2.adjacencies = new Edge[]{ new Edge(v1,  38.65) };
		v3.adjacencies = new Edge[]{ new Edge(v1, 102.53),
		                             new Edge(v5,  61.44),
		                             new Edge(v6,  96.79) };
		v4.adjacencies = new Edge[]{ new Edge(v5, 133.04) };
		v5.adjacencies = new Edge[]{ new Edge(v0,  81.77),
		                             new Edge(v3,  62.05),
		                             new Edge(v4, 134.47),
		                             new Edge(v6,  91.63) };
		v6.adjacencies = new Edge[]{ new Edge(v3,  97.24),
		                             new Edge(v5,  87.94) };

	
        computePaths(v0);
        for (Vertex v : vertices){
		    System.out.println("Distance to " + v + ": " + v.minDistance);
		    List<Vertex> path = getShortestPathTo(v);
		    System.out.println("Path: " + path);
		}
    }
*/    
}